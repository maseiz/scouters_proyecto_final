
import React from 'react';
import './App.css';
import Register from './Components/Register/formPlayers';

const App = () => {
  return (
    <Register />
    
  );
};

export default App;








